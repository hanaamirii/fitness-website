<?php
// Start the session to maintain admin login state
session_start();

// Include the database connection
require('DBconnection.php');

// Check if admin is logged in, if not redirect to admin login page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Function to sanitize input data (copied from process_register.php)
function sanitize($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Handle user deletion if requested
if (isset($_GET['delete_user']) && is_numeric($_GET['delete_user'])) {
    $user_id = sanitize($_GET['delete_user']);
    
    // Delete the user (foreign key constraints will handle consultation deletions)
    $delete_sql = "DELETE FROM users WHERE id = '$user_id'";
    
    if ($conn->query($delete_sql) === TRUE) {
        $delete_message = "User successfully deleted";
    } else {
        $delete_error = "Error deleting user: " . $conn->error;
    }
}

// Handle consultation status updates
if (isset($_POST['update_consultation'])) {
    $consultation_id = sanitize($_POST['consultation_id']);
    $new_status = sanitize($_POST['status']);
    $notes = sanitize($_POST['notes']);
    
    $update_sql = "UPDATE consultations SET status = '$new_status', notes = '$notes' WHERE id = '$consultation_id'";
    
    if ($conn->query($update_sql) === TRUE) {
        $update_message = "Consultation updated successfully";
    } else {
        $update_error = "Error updating consultation: " . $conn->error;
    }
}

// Determine which tab to show (default to users)
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'users';

// Pagination for users
$users_per_page = 10;
$user_page = isset($_GET['user_page']) ? (int)$_GET['user_page'] : 1;
$user_offset = ($user_page - 1) * $users_per_page;

// Search functionality for users
$user_search = isset($_GET['user_search']) ? sanitize($_GET['user_search']) : '';
$user_search_condition = '';
if (!empty($user_search)) {
    $user_search_condition = " WHERE firstname LIKE '%$user_search%' OR lastname LIKE '%$user_search%' OR email LIKE '%$user_search%' OR phone LIKE '%$user_search%'";
}

// Get total number of users for pagination
$count_users_sql = "SELECT COUNT(*) as total FROM users" . $user_search_condition;
$count_result = $conn->query($count_users_sql);
$total_users = $count_result->fetch_assoc()['total'];
$total_user_pages = ceil($total_users / $users_per_page);

// Fetch users
$users_sql = "SELECT * FROM users" . $user_search_condition . " ORDER BY created_at DESC LIMIT $user_offset, $users_per_page";
$users_result = $conn->query($users_sql);

// Pagination for consultations
$consultations_per_page = 10;
$consult_page = isset($_GET['consult_page']) ? (int)$_GET['consult_page'] : 1;
$consult_offset = ($consult_page - 1) * $consultations_per_page;

// Get total number of consultations for pagination
$count_consults_sql = "SELECT COUNT(*) as total FROM consultations";
$count_consult_result = $conn->query($count_consults_sql);
$total_consults = $count_consult_result->fetch_assoc()['total'];
$total_consult_pages = ceil($total_consults / $consultations_per_page);

// Fetch consultations with user information
$consultations_sql = "SELECT c.*, u.firstname, u.lastname, u.email, u.phone 
                     FROM consultations c 
                     JOIN users u ON c.user_id = u.id 
                     ORDER BY c.consultation_date DESC, c.consultation_time ASC 
                     LIMIT $consult_offset, $consultations_per_page";
$consultations_result = $conn->query($consultations_sql);

// Dashboard statistics
$stats = [
    'total_users' => $total_users,
    'new_users_today' => 0,
    'upcoming_consultations' => 0,
    'completed_consultations' => 0
];

// Get new users today
$today = date('Y-m-d');
$new_users_sql = "SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = '$today'";
$new_users_result = $conn->query($new_users_sql);
$stats['new_users_today'] = $new_users_result->fetch_assoc()['count'];

// Get upcoming consultations
$upcoming_sql = "SELECT COUNT(*) as count FROM consultations WHERE status = 'scheduled' AND consultation_date >= '$today'";
$upcoming_result = $conn->query($upcoming_sql);
$stats['upcoming_consultations'] = $upcoming_result->fetch_assoc()['count'];

// Get completed consultations
$completed_sql = "SELECT COUNT(*) as count FROM consultations WHERE status = 'completed'";
$completed_result = $conn->query($completed_sql);
$stats['completed_consultations'] = $completed_result->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Hana-Gym</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            color: white;
        }
        .sidebar a {
            color: #adb5bd;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover, .sidebar a.active {
            color: #fff;
            background-color: #495057;
        }
        .dashboard-stats {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .stat-card {
            background-color: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .stat-card i {
            font-size: 2rem;
            color: #0d6efd;
        }
        .tab-content {
            padding: 20px 0;
        }
        .admin-header {
            background-color: #0d6efd;
            color: white;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h2>Hana-Gym Admin Dashboard</h2>
                </div>
                <div class="col-md-6 text-end">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
                    <a href="admin_logout.php" class="btn btn-outline-light ms-3">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-0">
                <div class="pt-3">
                    <h4 class="text-center mb-4">Admin Panel</h4>
                    <a href="?tab=dashboard" class="<?php echo $active_tab == 'dashboard' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                    <a href="?tab=users" class="<?php echo $active_tab == 'users' ? 'active' : ''; ?>">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                    <a href="?tab=consultations" class="<?php echo $active_tab == 'consultations' ? 'active' : ''; ?>">
                        <i class="fas fa-calendar-check me-2"></i> Consultations
                    </a>
                    <a href="?tab=settings" class="<?php echo $active_tab == 'settings' ? 'active' : ''; ?>">
                        <i class="fas fa-cog me-2"></i> Settings
                    </a>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 p-4">
                <?php if (isset($delete_message)): ?>
                    <div class="alert alert-success"><?php echo $delete_message; ?></div>
                <?php endif; ?>
                
                <?php if (isset($delete_error)): ?>
                    <div class="alert alert-danger"><?php echo $delete_error; ?></div>
                <?php endif; ?>
                
                <?php if (isset($update_message)): ?>
                    <div class="alert alert-success"><?php echo $update_message; ?></div>
                <?php endif; ?>
                
                <?php if (isset($update_error)): ?>
                    <div class="alert alert-danger"><?php echo $update_error; ?></div>
                <?php endif; ?>

                <div class="tab-content">
                    <!-- Dashboard Tab -->
                    <?php if ($active_tab == 'dashboard'): ?>
                        <h3 class="mb-4">Dashboard Overview</h3>
                        <div class="dashboard-stats">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h5 class="card-title">Total Users</h5>
                                                <h2><?php echo $stats['total_users']; ?></h2>
                                            </div>
                                            <i class="fas fa-users"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h5 class="card-title">New Users Today</h5>
                                                <h2><?php echo $stats['new_users_today']; ?></h2>
                                            </div>
                                            <i class="fas fa-user-plus"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h5 class="card-title">Upcoming Consultations</h5>
                                                <h2><?php echo $stats['upcoming_consultations']; ?></h2>
                                            </div>
                                            <i class="fas fa-calendar"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="stat-card">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h5 class="card-title">Completed Consultations</h5>
                                                <h2><?php echo $stats['completed_consultations']; ?></h2>
                                            </div>
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        Recent Users
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Joined</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $recent_users_sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT 5";
                                                    $recent_users_result = $conn->query($recent_users_sql);
                                                    while ($user = $recent_users_result->fetch_assoc()): 
                                                    ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></td>
                                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                                    </tr>
                                                    <?php endwhile; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <a href="?tab=users" class="btn btn-sm btn-primary">View All Users</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        Upcoming Consultations
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Client</th>
                                                        <th>Date</th>
                                                        <th>Time</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $upcoming_consults_sql = "SELECT c.*, u.firstname, u.lastname 
                                                                              FROM consultations c 
                                                                              JOIN users u ON c.user_id = u.id 
                                                                              WHERE c.consultation_date >= '$today' 
                                                                              ORDER BY c.consultation_date ASC, c.consultation_time ASC 
                                                                              LIMIT 5";
                                                    $upcoming_consults_result = $conn->query($upcoming_consults_sql);
                                                    while ($consult = $upcoming_consults_result->fetch_assoc()): 
                                                    ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($consult['firstname'] . ' ' . $consult['lastname']); ?></td>
                                                        <td><?php echo date('M d, Y', strtotime($consult['consultation_date'])); ?></td>
                                                        <td><?php echo htmlspecialchars($consult['consultation_time']); ?></td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $consult['status'] == 'scheduled' ? 'warning' : ($consult['status'] == 'completed' ? 'success' : 'danger'); ?>">
                                                                <?php echo ucfirst(htmlspecialchars($consult['status'])); ?>
                                                            </span>
                                                        </td>
                                                    </tr>
                                                    <?php endwhile; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <a href="?tab=consultations" class="btn btn-sm btn-primary">View All Consultations</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Users Tab -->
                    <?php if ($active_tab == 'users'): ?>
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3>Users Management</h3>
                            <form class="d-flex" method="GET" action="">
                                <input type="hidden" name="tab" value="users">
                                <input type="text" name="user_search" class="form-control me-2" placeholder="Search users..." value="<?php echo htmlspecialchars($user_search); ?>">
                                <button type="submit" class="btn btn-outline-primary">Search</button>
                            </form>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                        <th>Created On</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($users_result->num_rows > 0): ?>
                                        <?php while ($user = $users_result->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $user['id']; ?></td>
                                                <td><?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?></td>
                                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                                <td><?php echo htmlspecialchars($user['phone']); ?></td>
                                                <td><?php echo $user['age']; ?></td>
                                                <td><?php echo ucfirst(htmlspecialchars($user['sex'])); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                                <td>
                                                    <a href="user_details.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info">View</a>
                                                    <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                                    <a href="?tab=users&delete_user=<?php echo $user['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No users found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination for users -->
                        <?php if ($total_user_pages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?php echo ($user_page <= 1) ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?tab=users&user_page=<?php echo $user_page - 1; ?>&user_search=<?php echo urlencode($user_search); ?>">Previous</a>
                                    </li>
                                    <?php for ($i = 1; $i <= $total_user_pages; $i++): ?>
                                        <li class="page-item <?php echo ($i == $user_page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?tab=users&user_page=<?php echo $i; ?>&user_search=<?php echo urlencode($user_search); ?>"><?php echo $i; ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    <li class="page-item <?php echo ($user_page >= $total_user_pages) ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?tab=users&user_page=<?php echo $user_page + 1; ?>&user_search=<?php echo urlencode($user_search); ?>">Next</a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Consultations Tab -->
                    <?php if ($active_tab == 'consultations'): ?>
                        <h3 class="mb-4">Consultations Management</h3>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>Client</th>
                                        <th>Contact</th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Notes</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($consultations_result->num_rows > 0): ?>
                                        <?php while ($consultation = $consultations_result->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo $consultation['id']; ?></td>
                                                <td><?php echo htmlspecialchars($consultation['firstname'] . ' ' . $consultation['lastname']); ?></td>
                                                <td>
                                                    <div><?php echo htmlspecialchars($consultation['email']); ?></div>
                                                    <div><?php echo htmlspecialchars($consultation['phone']); ?></div>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($consultation['consultation_date'])); ?></td>
                                                <td><?php echo htmlspecialchars($consultation['consultation_time']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php echo $consultation['status'] == 'scheduled' ? 'warning' : ($consultation['status'] == 'completed' ? 'success' : 'danger'); ?>">
                                                        <?php echo ucfirst(htmlspecialchars($consultation['status'])); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo htmlspecialchars($consultation['notes'] ?? 'No notes'); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#updateConsultation<?php echo $consultation['id']; ?>">
                                                        Update
                                                    </button>
                                                </td>
                                            </tr>
                                            
                                            <!-- Modal for updating consultation -->
                                            <div class="modal fade" id="updateConsultation<?php echo $consultation['id']; ?>" tabindex="-1" aria-labelledby="updateConsultationLabel<?php echo $consultation['id']; ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="updateConsultationLabel<?php echo $consultation['id']; ?>">Update Consultation</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form method="post" action="?tab=consultations&consult_page=<?php echo $consult_page; ?>">
                                                            <div class="modal-body">
                                                                <input type="hidden" name="consultation_id" value="<?php echo $consultation['id']; ?>">
                                                                
                                                                <div class="mb-3">
                                                                    <label for="status" class="form-label">Status</label>
                                                                    <select class="form-select" name="status" id="status" required>
                                                                        <option value="scheduled" <?php echo ($consultation['status'] == 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                                                                        <option value="completed" <?php echo ($consultation['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                                                        <option value="cancelled" <?php echo ($consultation['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                                                    </select>
                                                                </div>
                                                                
                                                                <div class="mb-3">
                                                                    <label for="notes" class="form-label">Notes</label>
                                                                    <textarea class="form-control" name="notes" id="notes" rows="3"><?php echo htmlspecialchars($consultation['notes'] ?? ''); ?></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" name="update_consultation" class="btn btn-primary">Save changes</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No consultations found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Pagination for consultations -->
                        <?php if ($total_consult_pages > 1): ?>
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center">
                                    <li class="page-item <?php echo ($consult_page <= 1) ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?tab=consultations&consult_page=<?php echo $consult_page - 1; ?>">Previous</a>
                                    </li>
                                    <?php for ($i = 1; $i <= $total_consult_pages; $i++): ?>
                                        <li class="page-item <?php echo ($i == $consult_page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?tab=consultations&consult_page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    <li class="page-item <?php echo ($consult_page >= $total_consult_pages) ? 'disabled' : ''; ?>">
                                        <a class="page-link" href="?tab=consultations&consult_page=<?php echo $consult_page + 1; ?>">Next</a>
                                    </li>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Settings Tab -->
                    <?php if ($active_tab == 'settings'): ?>
                        <h3 class="mb-4">Admin Settings</h3>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        Change Admin Password
                                    </div>
                                    <div class="card-body">
                                        <form method="post" action="update_admin_password.php">
                                            <div class="mb-3">
                                                <label for="current_password" class="form-label">Current Password</label>
                                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="new_password" class="form-label">New Password</label>
                                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="confirm_password" class="form-label">Confirm New Password</label>
                                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Update Password</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-header">
                                        System Settings
                                    </div>
                                    <div class="card-body">
                                        <form method="post" action="update_system_settings.php">
                                            <div class="mb-3">
                                                <label for="site_name" class="form-label">Site Name</label>
                                                <input type="text" class="form-control" id="site_name" name="site_name" value="Hana-Gym">
                                            </div>
                                            <div class="mb-3">
                                                <label for="admin_email" class="form-label">Admin Email</label>
                                                <input type="email" class="form-control" id="admin_email" name="admin_email" value="<?php echo htmlspecialchars($_SESSION['admin_email'] ?? 'admin@hanagym.com'); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="consultation_slots" class="form-label">Daily Consultation Slots</label>
                                                <input type="number" class="form-control" id="consultation_slots" name="consultation_slots" value="10">
                                            </div>
                                            <div class="mb-3">
                                                <label for="maintenance_mode" class="form-label">Maintenance Mode</label>
                                                <select class="form-select" id="maintenance_mode" name="maintenance_mode">
                                                    <option value="0">Off</option>
                                                    <option value="1">On</option>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Save Settings</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-header">
                                        Database Management
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <h5>Backup Database</h5>
                                                    <p>Create a backup of the current database.</p>
                                                    <a href="backup_database.php" class="btn btn-success">Create Backup</a>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="mb-3">
                                                    <h5>Restore Database</h5>
                                                    <p>Restore the database from a backup file.</p>
                                                    <form method="post" action="restore_database.php" enctype="multipart/form-data">
                                                        <div class="input-group">
                                                            <input type="file" class="form-control" id="backup_file" name="backup_file" accept=".sql">
                                                            <button type="submit" class="btn btn-warning">Restore</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Chart.js for potential dashboard charts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js"></script>
    <script>
        // Initialize any Bootstrap components that need JavaScript
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
        
        // can add charts here using Chart.js if needed
        // Example:
        /*
        const ctx = document.getElementById('userChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                    datasets: [{
                        label: 'New Users',
                        data: [12, 19, 3, 5, 2, 3],
                        borderColor: '#0d6efd',
                        tension: 0.1
                    }]
                }
            });
        }
        */
    </script>
</body>
</html>