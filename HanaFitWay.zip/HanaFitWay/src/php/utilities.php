<?php
// Check if sanitize function already exists before defining it
if (!function_exists('sanitize')) {
    function sanitize($data) {
        global $conn;
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $conn->real_escape_string($data);
    }
}
?>