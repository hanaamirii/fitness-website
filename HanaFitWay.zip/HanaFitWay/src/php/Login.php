<?php
require('DBconnection.php');
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'utilities.php';
    
    // Sanitize input
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    
    // Constructs a SQL query to get the user with the matching email.
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['firstname'] = $user['firstname'];
            
            // Redirect to dashboard
            header("Location: Userdash.php");
            exit();
        } else {
            $error_message = "Invalid password. Please try again.";
        }
    } else {
        $error_message = "No account found with this email. Please check your email or sign up.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Hana Fit Way</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    :root {
      --header-height: 80px;
      --primary-color: #FFD700;
      --transition-speed: 0.3s;
    }
    
    /* resets default browser styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: #000000;
      color: #f5f5f5;
      line-height: 1.6;
      padding-top: var(--header-height);
    }
    
    /* creates a black bar fixed at the top of the page that stays in place when scrolling*/
    .header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: var(--header-height);
      background-color: #000000;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      z-index: 1000;
      display: flex;
      align-items: center;
      padding: 0 5%;
    }
    
    /* Logo section takes 30% width of the header */
    .logo-section {
      flex: 0 0 30%;
      height: 100%;
      display: flex;
      align-items: center;
    }
    
    .logo {
      display: flex;
      align-items: center;
      text-decoration: none;
    }
    
    .logo-img {
      max-height: 60px;
      max-width: 100%;
    }
    
    /* Navigation takes 70% width */
    .navigation {
      flex: 0 0 70%;
      height: 100%;
      display: flex;
      justify-content: flex-end;
      align-items: center;
    }
    
    .nav-links {
      display: flex;
      list-style: none;
      margin: 0;
      align-items: center;
      height: 100%;
    }
    
    .nav-links li {
      display: flex;
      align-items: center;
      height: 100%;
      margin-left: 30px;
    }
    
    .nav-item {
      color: #ffffff;
      text-decoration: none;
      font-size: 16px;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    
    .nav-item:hover {
      color: var(--primary-color);
      text-decoration: none;
    }
    
    /* Social Icons */
    .nav-social {
      display: flex;
      align-items: center;
      margin-left: 20px;
    }
    
    .nav-social a {
      margin-left: 15px;
      font-size: 20px;
      color: #ffffff;
      transition: color 0.3s ease;
    }
    
    .nav-social a.instagram:hover {
      color:rgb(225, 48, 163);
    }
    
    .nav-social a.youtube:hover {
      color: #FF0000;
    }
    
    /* Trial Button */
    .trial-btn {
      background-color: var(--primary-color);
      color: #000000;
      padding: 12px 20px;
      border-radius: 50px;
      font-weight: 600;
      text-transform: uppercase;
      text-decoration: none;
      margin-left: 30px;
      transition: all 0.3s ease;
      font-size: 14px;
      letter-spacing: 0.5px;
    }
    
    .trial-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(255, 215, 0, 0.3);
      color: #000000;
    }
    
    /* Mobile Menu */
    .mobile-menu-toggle {
      display: none;
      color: #ffffff;
      font-size: 24px;
      cursor: pointer;
    }
    
    /* Container Styling */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
    }
    
    .main-container {
      margin-top: 40px;
      padding: 0 20px;
    }

    .login-container {
      display: flex;
      background-color: #1e1e1e;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
      max-width: 900px;
      margin: 0 auto;
    }

    /* Form Section */
    .form-container {
      flex: 1;
      padding: 40px;
      background-color: #1e1e1e;
    }

    .form-container h1 {
      color: #FFD700;
      margin-bottom: 15px;
      font-size: 2.2rem;
      font-weight: 700;
    }

    .form-subtitle {
      color: #e0e0e0;
      margin-bottom: 30px;
      font-size: 1rem;
    }

    /* Form Layout */
    .form-group {
      margin-bottom: 25px;
    }

    .input-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 20px;
    }

    /* Input Fields */
    label {
      margin-bottom: 8px;
      font-weight: 500;
      color: #FFD700;
    }

    input[type="email"],
    input[type="password"] {
      padding: 12px 15px;
      border: 1px solid #333;
      border-radius: 6px;
      background-color: #2a2a2a;
      color: #fff;
      font-size: 16px;
      transition: all 0.3s ease;
    }

    input:focus {
      outline: none;
      border-color: #FFD700;
      box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.2);
    }

    /* Button Styling */
    .submit-btn {
      background-color: #FFD700;
      color: #000;
      border: none;
      border-radius: 6px;
      padding: 14px 25px;
      font-size: 18px;
      font-weight: 600;
      cursor: pointer;
      width: 100%;
      transition: all 0.3s ease;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 25px;
    }

    .submit-btn:hover {
      background-color: #e6c200;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);
    }

    .submit-btn:active {
      transform: translateY(0);
    }

    /* Error Message */
    .error-message {
      background-color: rgba(255, 0, 0, 0.1);
      border-left: 4px solid #ff3333;
      padding: 12px;
      margin-bottom: 20px;
      color: #ff6666;
      border-radius: 4px;
    }

    /* Signup Link */
    .signup-link {
      text-align: center;
      margin-top: 25px;
      color: #ccc;
    }

    .signup-link a {
      color: #FFD700;
      text-decoration: none;
      font-weight: 500;
    }

    .signup-link a:hover {
      text-decoration: underline;
    }

    /* Brand Section */
    .brand-container {
      flex: 1;
      background-color: #252525;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
      overflow: hidden;
      text-align: center;
    }

    .brand-container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(0, 0, 0, 0) 100%);
      z-index: 0;
    }

    .logo-branding {
      font-size: 2.5rem;
      font-weight: 800;
      color: #FFD700;
      margin-bottom: 30px;
      position: relative;
      z-index: 1;
    }

    .brand-tagline {
      color: #e0e0e0;
      font-size: 1.2rem;
      margin-bottom: 40px;
      position: relative;
      z-index: 1;
    }

    .brand-features {
      position: relative;
      z-index: 1;
      color: #ccc;
      text-align: left;
      padding-left: 20px;
      list-style: none;
    }

    .brand-features li {
      margin-bottom: 12px;
      font-size: 1rem;
      display: flex;
      align-items: center;
    }

    .brand-features i {
      color: #FFD700;
      margin-right: 10px;
    }

    /* Responsive Design */
    @media (max-width: 992px) {
      .nav-links li {
        margin-left: 20px;
      }
      
      .trial-btn {
        margin-left: 20px;
      }
    }
    
    @media (max-width: 768px) {
      .login-container {
        flex-direction: column;
      }
      
      .brand-container {
        padding: 30px;
        order: -1;
      }
      
      .form-container {
        padding: 30px 20px;
      }
      
      /* Mobile Navigation */
      .mobile-menu-toggle {
        display: block;
      }
      
      .navigation {
        justify-content: flex-end;
      }
      
      .nav-links {
        display: none;
        position: absolute;
        top: var(--header-height);
        left: 0;
        width: 100%;
        flex-direction: column;
        background-color: #000000;
        padding: 20px 0;
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
      }
      
      .nav-links.active {
        display: flex;
      }
      
      .nav-links li {
        margin: 10px 0;
        width: 100%;
        height: auto;
        text-align: center;
      }
      
      .nav-social {
        justify-content: center;
        margin: 15px 0;
      }
      
      .trial-btn {
        margin: 10px auto;
        display: inline-block;
      }
    }
  </style>
</head>
<body>
  <!-- Modern Header Section based on Image 2 -->
  <header class="header">
    <!-- Logo Section -->
    <div class="logo-section">
      <a href="../index.html" class="logo">
        <img src="../images/LOGOheader.png" alt="HanaFitWay LOGO" class="logo-img">
      </a>
    </div>
    
    <!-- Navigation Section -->
    <nav class="navigation">
      <!-- Mobile Menu Toggle -->
      <div class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class="fas fa-bars"></i>
      </div>
      
      <!-- Navigation Links -->
      <ul class="nav-links" id="navLinks">
        <li><a href="index.html" class="nav-item">Home</a></li>
        <li><a href="php/Login.php" class="nav-item">Members Club</a></li>
        <li><a href="index.html#about" class="nav-item">About Us</a></li>
        
        <!-- Social Icons -->
        <li class="nav-social">
          <a href="https://www.instagram.com/hanaamirii" target="_blank" class="instagram">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="https://www.youtube.com/@HanaFitWay" target="_blank" class="youtube">
            <i class="fab fa-youtube"></i>
          </a>
        </li>
        
        <!-- Trial Button -->
        <li>
          <a href="Trial.html" class="trial-btn">START FREE TRIAL</a>
        </li>
      </ul>
    </nav>
  </header>

  <div class="main-container">
    <div class="login-container">
      <div class="form-container">
        <h1>Welcome Back</h1>
        <p class="form-subtitle">Log in to your Hana Fit Way account</p>
        
        <?php if (isset($error_message)): ?>
          <div class="error-message">
            <?php echo $error_message; ?>
          </div>
        <?php endif; ?>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
          <div class="form-group">
            <div class="input-group">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required>
            </div>
            
            <div class="input-group">
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="submit-btn">Log In</button>
          </div>
        </form>
        
        <div class="signup-link">
          Don't have an account? <a href="signup.php">Sign up now</a>
        </div>
      </div>
      
      <div class="brand-container">
        <div class="logo-branding">Hana Fit Way</div>
        <p class="brand-tagline">Transform your fitness journey with us</p>
        
        <ul class="brand-features">
          <li><i class="fas fa-check-circle"></i> Personalized workout plans</li>
          <li><i class="fas fa-check-circle"></i> Expert nutrition guidance</li>
          <li><i class="fas fa-check-circle"></i> Progress tracking tools</li>
          <li><i class="fas fa-check-circle"></i> Supportive community</li>
        </ul>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script>
    // JavaScript for mobile menu toggle
    document.addEventListener('DOMContentLoaded', function() {
      const mobileMenuToggle = document.getElementById('mobileMenuToggle');
      const navLinks = document.getElementById('navLinks');
      
      if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
          navLinks.classList.toggle('active');
        });
      }
    });
  </script>
</body>
</html>