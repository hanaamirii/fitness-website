<?php
require('DBconnection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Join Hana Fit Way - Registration</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: #121212;
      color: #f5f5f5;
      line-height: 1.6;
    }

    /* Container Styling */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 20px;
    }

    .registration-container {
      display: flex;
      background-color: #1e1e1e;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
      margin: 20px 0;
    }

    /* Form Section */
    .form-container {
      flex: 2;
      padding: 40px;
      background-color: #1e1e1e;
    }

    .form-container h1 {
      color: #FFD700; /* Yellow gold */
      margin-bottom: 15px;
      font-size: 2.2rem;
      font-weight: 700;
    }

    .form-subtitle {
      color: #e0e0e0;
      margin-bottom: 30px;
      font-size: 1rem;
    }

    /* Form Layout */
    .form-group {
      margin-bottom: 25px;
    }

    .form-row {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
    }

    .input-group {
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    /* Added full-width class for single password field */
    .input-group.full-width {
      width: 100%;
    }

    /* Input Fields */
    label {
      margin-bottom: 8px;
      font-weight: 500;
      color: #FFD700;
    }

    input[type="text"],
    input[type="email"],
    input[type="password"],
    input[type="tel"],
    input[type="number"],
    input[type="date"],
    select {
      padding: 12px 15px;
      border: 1px solid #333;
      border-radius: 6px;
      background-color: #2a2a2a;
      color: #fff;
      font-size: 16px;
      transition: all 0.3s ease;
    }

    input:focus,
    select:focus {
      outline: none;
      border-color: #FFD700;
      box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.2);
    }

    /* Radio Buttons */
    .radio-group {
      display: flex;
      gap: 15px;
      align-items: center;
    }

    .radio-group input[type="radio"] {
      margin-right: 5px;
      accent-color: #FFD700;
    }

    /* Section Styling */
    .form-section {
      background-color: #262626;
      padding: 20px;
      border-radius: 8px;
      margin: 30px 0;
      border-left: 4px solid #FFD700;
    }

    .form-section h3 {
      color: #FFD700;
      margin-bottom: 10px;
      font-size: 1.3rem;
    }

    .form-section p {
      color: #ccc;
      margin-bottom: 20px;
      font-size: 0.9rem;
    }

    /* Checkbox Styling */
    .terms {
      display: flex;
      align-items: center;
      margin: 25px 0;
    }

    .terms input[type="checkbox"] {
      margin-right: 10px;
      accent-color: #FFD700;
      width: 18px;
      height: 18px;
    }

    .terms a {
      color: #FFD700;
      text-decoration: none;
    }

    .terms a:hover {
      text-decoration: underline;
    }

    /* Button Styling */
    .submit-btn {
      background-color: #FFD700;
      color: #000;
      border: none;
      border-radius: 6px;
      padding: 14px 25px;
      font-size: 18px;
      font-weight: 600;
      cursor: pointer;
      width: 100%;
      transition: all 0.3s ease;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 10px;
    }

    .submit-btn:hover {
      background-color: #e6c200;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(255, 215, 0, 0.3);
    }

    .submit-btn:active {
      transform: translateY(0);
    }

    /* Login Link */
    .login-link {
      text-align: center;
      margin-top: 25px;
      color: #ccc;
    }

    .login-link a {
      color: #FFD700;
      text-decoration: none;
      font-weight: 500;
    }

    .login-link a:hover {
      text-decoration: underline;
    }

    /* Benefits Section */
    .benefits {
      flex: 1;
      background-color: #252525;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }

    .benefits::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(0, 0, 0, 0) 100%);
      z-index: 0;
    }

    .benefits h2 {
      color: #FFD700;
      margin-bottom: 30px;
      font-size: 1.8rem;
      position: relative;
      z-index: 1;
    }

    .benefits ul {
      list-style: none;
      position: relative;
      z-index: 1;
    }

    .benefits li {
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      font-size: 1.1rem;
      color: #e0e0e0;
    }

    .benefits i {
      color: #FFD700;
      margin-right: 15px;
      font-size: 1.2rem;
    }

    /* Responsive Design */
    @media (max-width: 992px) {
      .registration-container {
        flex-direction: column;
      }
      
      .benefits {
        padding: 30px;
      }
    }

    @media (max-width: 768px) {
      .form-row {
        flex-direction: column;
        gap: 15px;
      }
      
      .form-container {
        padding: 30px 20px;
      }
      
      .form-container h1 {
        font-size: 1.8rem;
      }
    }
  </style>
</head>
<body>
    <main>
      <div class="container">
        <div class="registration-container">
          <div class="form-container">
            <h1>Start Your Fitness Journey</h1>
            <p class="form-subtitle">Join Hana Fit Way today and transform your life with our expert trainers and nutritionists</p>
            
            <div class="form-group">
                <form action="process_register.php" method="post">
                <div class="form-section">
                  <h3>Schedule Your Free Nutrition Consultation</h3>
                  <p>Our certified nutritionists will create a customized meal plan for your goals</p>
                  
                  <div class="form-row">
                    <div class="input-group">
                      <label for="consultation_time">Preferred Time</label>
                      <select id="consultation_time" name="consultation_time" required>
                        <option value="">Select a time</option>
                        <option value="9:00">9:00 AM</option>
                        <option value="10:00">10:00 AM</option>
                        <option value="11:00">11:00 AM</option>
                        <option value="12:00">12:00 PM</option>
                        <option value="13:00">1:00 PM</option>
                        <option value="14:00">2:00 PM</option>
                        <option value="15:00">3:00 PM</option>
                        <option value="16:00">4:00 PM</option>
                        <option value="17:00">5:00 PM</option>
                      </select>
                    </div>
                    <div class="input-group">
                      <label for="consultation_date">Preferred Date</label>
                      <input type="date" id="consultation_date" name="consultation_date" required>
                    </div>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="input-group">
                    <label for="firstname">First Name</label>
                    <input type="text" id="firstname" name="firstname" required>
                  </div>
                  <div class="input-group">
                    <label for="lastname">Last Name</label>
                    <input type="text" id="lastname" name="lastname" required>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="input-group">
                    <label for="weight">Weight (kg)</label>
                    <input type="number" id="weight" name="weight" min="30" max="300" required>
                  </div>
                  <div class="input-group">
                    <label for="height">Height (cm)</label>
                    <input type="number" id="height" name="height" min="100" max="250" required>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="input-group">
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" min="12" max="100" required>
                  </div>
                  <div class="input-group">
                    <label>Sex</label>
                    <div class="radio-group">
                      <input type="radio" id="male" name="sex" value="male" required>
                      <label for="male">Male</label>
                      <input type="radio" id="female" name="sex" value="female">
                      <label for="female">Female</label>
                      <input type="radio" id="other" name="sex" value="other">
                      <label for="other">Other</label>
                    </div>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                  </div>
                  <div class="input-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" title="Please enter a valid 10-digit phone number" required>
                  </div>
                </div>
                
                <div class="form-row">
                  <div class="input-group full-width">
                    <label for="password">Choose a Password</label>
                    <input type="password" id="password" name="password" required>
                  </div>
                </div>
                
                <div class="terms">
                  <input type="checkbox" id="terms" name="terms" required>
                  <label for="terms">I agree to the <a href="terms.html">Terms of Service</a> and <a href="privacy.html">Privacy Policy</a></label>
                </div>
                
                <button type="submit" class="submit-btn">Join Hana Fit Way</button>
              </div>
            </form>
            
            <div class="login-link">
              Already a member? <a href="login.php">Sign in here</a>
            </div>
          </div>
          
          <div class="benefits">
            <h2>Benefits of Joining Hana Fit Way</h2>
            <ul>
              <li><i class="fas fa-check-circle"></i> Personalized nutrition planning</li>
              <li><i class="fas fa-check-circle"></i> Access to all fitness classes</li>
              <li><i class="fas fa-check-circle"></i> Progress tracking tools</li>
              <li><i class="fas fa-check-circle"></i> Expert trainers support</li>
              <li><i class="fas fa-check-circle"></i> Flexible workout schedules</li>
            </ul>
          </div>
        </div>
      </div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>