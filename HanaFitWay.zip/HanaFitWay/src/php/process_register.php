<?php
require('DBconnection.php');

// Function to sanitize user input
function sanitize($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Function to check if email already exists
function emailExists($email) {
    global $conn;
    
    // Create the users table if it doesn't exist (first time setup)
    $create_table_sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(50) NOT NULL,
        lastname VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        weight DECIMAL(5,2),
        height DECIMAL(5,2),
        age INT,
        sex ENUM('male', 'female', 'other'),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $conn->query($create_table_sql);
    
    // Check if email exists
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    
    return $result->num_rows > 0;
}

// Process form data when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $firstname = sanitize($_POST['firstname']);
    $lastname = sanitize($_POST['lastname']);
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    $phone = sanitize($_POST['phone']);
    $weight = sanitize($_POST['weight']);
    $height = sanitize($_POST['height']);
    $age = sanitize($_POST['age']);
    $sex = sanitize($_POST['sex']);
    
    // Optional: Get consultation details
    $consultation_date = isset($_POST['consultation_date']) ? sanitize($_POST['consultation_date']) : null;
    $consultation_time = isset($_POST['consultation_time']) ? sanitize($_POST['consultation_time']) : null;
    
    // Check if email already exists
    if (emailExists($email)) {
        // Redirect with error
        header("Location: signup.php?error=email_exists");
        exit();
    }
    
    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $sql = "INSERT INTO users (firstname, lastname, email, password, phone, weight, height, age, sex) 
            VALUES ('$firstname', '$lastname', '$email', '$hashed_password', '$phone', '$weight', '$height', '$age', '$sex')";
    
    if ($conn->query($sql) === TRUE) {
        $user_id = $conn->insert_id;
        
        // If consultation was scheduled, create consultation record
        if ($consultation_date && $consultation_time) {
            // Create consultations table if it doesn't exist
            $create_consult_table = "CREATE TABLE IF NOT EXISTS consultations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                consultation_date DATE NOT NULL,
                consultation_time VARCHAR(10) NOT NULL,
                status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )";
            
            $conn->query($create_consult_table);
            
            // Insert consultation record
            $consult_sql = "INSERT INTO consultations (user_id, consultation_date, consultation_time) 
                           VALUES ('$user_id', '$consultation_date', '$consultation_time')";
            $conn->query($consult_sql);
        }
        
        // Start session and set session variables
        session_start();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['email'] = $email;
        $_SESSION['firstname'] = $firstname;
        
        // Redirect to dashboard
        header("Location: userdash.php");
        exit();
    } else {
        // Redirect with error
        header("Location: signup.php?error=registration_failed");
        exit();
    }
} else {
    // Not a POST request, redirect to registration page
    header("Location: signup.php");
    exit();
}
?>