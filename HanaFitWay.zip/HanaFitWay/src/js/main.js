// Main JavaScript for HanaFitWay

document.addEventListener('DOMContentLoaded', function() {
      // Initialize Hero Carousel
      initCarousel();
      
      // Initialize Smooth Scrolling
      initSmoothScroll();
      
      // Header Scroll Effect
      initHeaderScroll();
  });
  
  // Carousel functionality
  function initCarousel() {
      const slides = document.querySelectorAll('.carousel-slide');
      const indicators = document.querySelectorAll('.indicator');
      let currentSlide = 0;
      const slideInterval = 5000; // 5 seconds
      
      // Auto slide function
      function autoSlide() {
          slides[currentSlide].classList.remove('active');
          indicators[currentSlide].classList.remove('active');
          
          currentSlide = (currentSlide + 1) % slides.length;
          
          slides[currentSlide].classList.add('active');
          indicators[currentSlide].classList.add('active');
      }
      
      // Start auto sliding
      let slideTimer = setInterval(autoSlide, slideInterval);
      
      // Click handlers for indicators
      indicators.forEach((indicator, index) => {
          indicator.addEventListener('click', () => {
              // Clear the auto slide interval
              clearInterval(slideTimer);
              
              // Remove active class from all slides and indicators
              slides.forEach(slide => slide.classList.remove('active'));
              indicators.forEach(ind => ind.classList.remove('active'));
              
              // Set the current slide
              currentSlide = index;
              
              // Add active class to current slide and indicator
              slides[currentSlide].classList.add('active');
              indicators[currentSlide].classList.add('active');
              
              // Restart auto sliding
              slideTimer = setInterval(autoSlide, slideInterval);
          });
      });
  }
  
  // Smooth scrolling
  function initSmoothScroll() {
      const navLinks = document.querySelectorAll('a[href^="#"]');
      
      navLinks.forEach(link => {
          link.addEventListener('click', function(e) {
              const targetId = this.getAttribute('href');
              
              if (targetId === '#') return;
              
              e.preventDefault();
              
              const targetElement = document.querySelector(targetId);
              
              if (targetElement) {
                  const headerHeight = document.querySelector('.header').offsetHeight;
                  const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                  
                  window.scrollTo({
                      top: targetPosition,
                      behavior: 'smooth'
                  });
                  
                  // Close mobile menu if open
                  const navLinks = document.querySelector('.nav-links');
                  if (navLinks.classList.contains('active')) {
                      navLinks.classList.remove('active');
                  }
              }
          });
      });
  }
  
  // Header scroll effect
  function initHeaderScroll() {
      const header = document.querySelector('.header');
      
      window.addEventListener('scroll', () => {
          if (window.scrollY > 100) {
              header.classList.add('scrolled');
          } else {
              header.classList.remove('scrolled');
          }
      });
  }
  
  // Mobile navigation toggle
  document.addEventListener('DOMContentLoaded', function() {
      // Add mobile toggle button to DOM
      const nav = document.querySelector('.nav');
      const mobileToggle = document.createElement('div');
      mobileToggle.className = 'mobile-toggle d-md-none';
      mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
      nav.prepend(mobileToggle);
      
      // Toggle mobile menu
      mobileToggle.addEventListener('click', function() {
          const navLinks = document.querySelector('.nav-links');
          navLinks.classList.toggle('active');
          
          // Toggle icon
          const icon = this.querySelector('i');
          if (navLinks.classList.contains('active')) {
              icon.classList.remove('fa-bars');
              icon.classList.add('fa-times');
          } else {
              icon.classList.remove('fa-times');
              icon.classList.add('fa-bars');
          }
      });
      
      // Close mobile menu when clicking outside
      document.addEventListener('click', function(e) {
          const nav = document.querySelector('.nav');
          const navLinks = document.querySelector('.nav-links');
          
          if (!nav.contains(e.target) && navLinks.classList.contains('active')) {
              navLinks.classList.remove('active');
              
              // Reset icon
              const icon = document.querySelector('.mobile-toggle i');
              icon.classList.remove('fa-times');
              icon.classList.add('fa-bars');
          }
      });
  });