<?php
$host = 'mysql';
$user = 'Hana';
$password = 'root';
$db = 'Hana-Gym';
$conn = mysqli_connect($host, $user, $password, $db);

// Check the connection
try {
    if (!$conn) {
        throw new Exception(mysqli_connect_error());
    }
    mysqli_set_charset($conn, 'utf8mb4');
} catch (Exception $e) {
    error_log("Connection failed: " . $e->getMessage());
    die("Connection error. Please try again later.");
}

// Function to sanitize input data
require_once 'utilities.php';

// Check if the connection was successful
if (!$conn) {
    echo "Connection error: " . mysqli_connect_error();
}

?>