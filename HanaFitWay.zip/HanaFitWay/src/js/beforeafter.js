// JavaScript for Before/After Slider functionality

document.addEventListener('DOMContentLoaded', function() {
      initBeforeAfterSliders();
  });
  
  function initBeforeAfterSliders() {
      const comparisonContainers = document.querySelectorAll('.comparison-container');
      
      comparisonContainers.forEach(container => {
          const slider = container.querySelector('.slider');
          const beforeImage = container.querySelector('.before-image');
          const afterImage = container.querySelector('.after-image');
          let isActive = false;
          
          // Set initial position
          positionSlider(50, afterImage, slider);
          
          // Functions to handle slider movement
          function startSliding(e) {
              e.preventDefault();
              isActive = true;
              
              // Add event listeners for moving and stopping
              document.addEventListener('mousemove', moveSlider);
              document.addEventListener('touchmove', moveSlider);
              document.addEventListener('mouseup', stopSliding);
              document.addEventListener('touchend', stopSliding);
          }
          
          function moveSlider(e) {
              if (!isActive) return;
              
              const rect = container.getBoundingClientRect();
              let x;
              
              // Check if it's a touch event or mouse event
              if (e.type === 'touchmove') {
                  x = e.touches[0].clientX - rect.left;
              } else {
                  x = e.clientX - rect.left;
              }
  
              // Calculate percentage
              const percentage = Math.max(0, Math.min(100, x / rect.width * 100));
              
              // Position the slider and after image
              positionSlider(percentage, afterImage, slider);
          }
          
          function stopSliding() {
              isActive = false;
              
              // Remove event listeners
              document.removeEventListener('mousemove', moveSlider);
              document.removeEventListener('touchmove', moveSlider);
              document.removeEventListener('mouseup', stopSliding);
              document.removeEventListener('touchend', stopSliding);
          }
          
          // Add event listeners for starting the slide
          slider.addEventListener('mousedown', startSliding);
          slider.addEventListener('touchstart', startSliding);
          
          // Handle click anywhere in the container
          container.addEventListener('click', function(e) {
              const rect = container.getBoundingClientRect();
              const x = e.clientX - rect.left;
              const percentage = Math.max(0, Math.min(100, x / rect.width * 100));
              
              // Animate the slider movement
              animateSlider(parseFloat(afterImage.style.width) || 50, percentage, afterImage, slider);
          });
      });
  }
  
  // Function to position the slider and after image
  function positionSlider(percentage, afterImage, slider) {
      afterImage.style.width = percentage + '%';
      slider.style.left = percentage + '%';
  }
  
  // Function to animate the slider movement
  function animateSlider(startPercentage, endPercentage, afterImage, slider) {
      const duration = 300; // Animation duration in ms
      const startTime = performance.now();
      
      function animate(currentTime) {
          const elapsedTime = currentTime - startTime;
          const progress = Math.min(elapsedTime / duration, 1);
          const easedProgress = easeInOutCubic(progress);
          
          const currentPercentage = startPercentage + (endPercentage - startPercentage) * easedProgress;
          positionSlider(currentPercentage, afterImage, slider);
          
          if (progress < 1) {
              requestAnimationFrame(animate);
          }
      }
      
      requestAnimationFrame(animate);
  }
  
  // Easing function for smoother animation
  function easeInOutCubic(t) {
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }