<?php
require('DBconnection.php');
session_start();

// Check if user is logged in, if not redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user data from database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
} else {
    // Handle error - user not found in database
    header("Location: login.php");
    exit();
}

// Get consultation data if exists
$consult_sql = "SELECT consultation_date, consultation_time FROM consultations WHERE user_id = '$user_id'";
$consult_result = $conn->query($consult_sql);
$consultation = $consult_result->num_rows > 0 ? $consult_result->fetch_assoc() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Dashboard - Hana Fit Way</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
      background-color: #121212;
      color: #f5f5f5;
      line-height: 1.6;
    }

    /* Navigation */
    .navbar {
      background-color: #1e1e1e;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
    }

    .navbar-brand {
      color: #FFD700;
      font-weight: 700;
      font-size: 1.8rem;
    }

    .navbar-dark .navbar-nav .nav-link {
      color: #e0e0e0;
      padding: 0.5rem 1rem;
      transition: all 0.3s ease;
    }

    .navbar-dark .navbar-nav .nav-link:hover,
    .navbar-dark .navbar-nav .nav-link.active {
      color: #FFD700;
    }

    .navbar-dark .navbar-toggler {
      border-color: #333;
    }

    .logout-btn {
      background-color: transparent;
      border: 1px solid #FFD700;
      color: #FFD700;
      transition: all 0.3s ease;
    }

    .logout-btn:hover {
      background-color: #FFD700;
      color: #000;
    }

    /* Container Styling */
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 40px 20px;
    }

    .dashboard-container {
      background-color: #1e1e1e;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
      margin-top: 20px;
    }

    /* Header Section */
    .dashboard-header {
      background-color: #252525;
      padding: 30px;
      border-bottom: 1px solid #333;
      position: relative;
    }

    .dashboard-header::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(0, 0, 0, 0) 100%);
      z-index: 0;
    }

    .welcome-text {
      position: relative;
      z-index: 1;
    }

    .welcome-text h1 {
      color: #FFD700;
      margin-bottom: 10px;
      font-size: 2.2rem;
      font-weight: 700;
    }

    .welcome-text p {
      color: #ccc;
      font-size: 1.1rem;
    }

    /* Content Section */
    .dashboard-content {
      padding: 30px;
    }

    .info-section {
      margin-bottom: 40px;
    }

    .info-section h2 {
      color: #FFD700;
      margin-bottom: 20px;
      font-size: 1.8rem;
      padding-bottom: 10px;
      border-bottom: 1px solid #333;
    }

    /* User Information Cards */
    .info-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 20px;
    }

    .info-card {
      background-color: #252525;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
      transition: all 0.3s ease;
    }

    .info-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
    }

    .info-card h3 {
      color: #FFD700;
      font-size: 1.2rem;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
    }

    .info-card h3 i {
      margin-right: 10px;
    }

    .info-card p {
      color: #e0e0e0;
      font-size: 1.1rem;
      margin-bottom: 0;
    }

    /* Consultation Section */
    .consultation-card {
      background-color: #252525;
      border-radius: 8px;
      padding: 25px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
      margin-bottom: 30px;
      border-left: 4px solid #FFD700;
    }

    .consultation-card h3 {
      color: #FFD700;
      margin-bottom: 15px;
    }

    .consultation-details {
      display: flex; /*lay out multiple child items in a row*/
      flex-wrap: wrap;  /*allows them to wrap on smaller screens*/
      gap: 20px;
    }

    .consultation-item {
      flex: 1; /*allows to grow evenly*/
      min-width: 200px;
    }

    .consultation-item label {
      display: block;
      color: #aaa;
      margin-bottom: 5px;
      font-size: 0.9rem;
    }

    .consultation-item p {
      color: #fff;
      font-size: 1.1rem;
      margin-bottom: 0;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .dashboard-header {
        padding: 20px;
      }
      
      .welcome-text h1 {
        font-size: 1.8rem;
      }
      
      .dashboard-content {
        padding: 20px;
      }
      
      .info-section h2 {
        font-size: 1.5rem;
      }
      
      .info-cards {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container"> <!--to center and properly space the content inside the navbar-->
      <a class="navbar-brand" href="../index.html">Hana Fit Way</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link active" href="userdash.php">Dashboard</a>
          </li>
        </ul>
        <form action="logout.php" method="post">
          <button type="submit" class="btn logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
          </button>
        </form>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="container">
    <div class="dashboard-container">
      <!-- Dashboard Header -->
      <div class="dashboard-header">
        <div class="welcome-text">
          <h1>Welcome, <?php echo htmlspecialchars($user_data['firstname']); ?>!</h1>
          <p>Track your fitness journey and manage your personal information</p>
        </div>
      </div>
      
      <!-- Dashboard Content -->
      <div class="dashboard-content">
        <?php if ($consultation): ?>
        <!-- Consultation Information -->
        <div class="info-section">
          <h2>Your Nutrition Consultation</h2>
          <div class="consultation-card">
            <h3><i class="fas fa-calendar-check"></i> Upcoming Consultation</h3>
            <div class="consultation-details">
              <div class="consultation-item">
                <label>Date:</label>
                <p><?php echo htmlspecialchars($consultation['consultation_date']); ?></p>
              </div>
              <div class="consultation-item">
                <label>Time:</label>
                <p><?php echo htmlspecialchars($consultation['consultation_time']); ?></p>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
        
        <!-- Personal Information Section -->
        <div class="info-section">
          <h2>Personal Information</h2>
          <div class="info-cards">
            <div class="info-card">
              <h3><i class="fas fa-user"></i> Name</h3>
              <p><?php echo htmlspecialchars($user_data['firstname'] . ' ' . $user_data['lastname']); ?></p> <!--Securely outputs data with htmlspecialchars() to avoid malicious input being interpreted as HTML. -->
            </div>
  
            <div class="info-card">
              <h3><i class="fas fa-envelope"></i> Email</h3>
              <p><?php echo htmlspecialchars($user_data['email']); ?></p>
            </div>
            
            <div class="info-card">
              <h3><i class="fas fa-phone"></i> Phone</h3>
              <p><?php echo htmlspecialchars($user_data['phone']); ?></p>
            </div>
          </div>
        </div>
        
        <!-- Physical Information Section -->
        <div class="info-section">
          <h2>Physical Information</h2>
          <div class="info-cards">
            <div class="info-card">
              <h3><i class="fas fa-weight"></i> Weight</h3>
              <p><?php echo htmlspecialchars($user_data['weight']); ?> kg</p>
            </div> <!--Data: Echoes the user's weight (from PHP array $user_data['weight']) with a kg unit.--> 
            
            <div class="info-card">
              <h3><i class="fas fa-ruler-vertical"></i> Height</h3>
              <p><?php echo htmlspecialchars($user_data['height']); ?> cm</p>
            </div>  <!--Uses htmlspecialchars() to prevent XSS attacks.--> 
            <!--Data: Displays height in centimeters from the PHP variable.-->

            <div class="info-card">
              <h3><i class="fas fa-birthday-cake"></i> Age</h3>
              <p><?php echo htmlspecialchars($user_data['age']); ?> years</p>
            </div>
            
            <div class="info-card">
              <h3><i class="fas fa-venus-mars"></i> Sex</h3>
              <p><?php echo htmlspecialchars(ucfirst($user_data['sex'])); ?></p> <!--Data: Displays the sex of the user--> 
            </div>
            <!--ucfirst() is used to capitalize the first letter --> 
            <?php 
            // Calculate BMI if weight and height are available
            if ($user_data['weight'] && $user_data['height']) {
              $height_m = $user_data['height'] / 100;
              $bmi = round($user_data['weight'] / ($height_m * $height_m), 1);
              
              // Determine BMI category
              $bmi_category = '';
              if ($bmi < 18.5) {
                $bmi_category = 'Underweight';
              } elseif ($bmi >= 18.5 && $bmi < 25) {
                $bmi_category = 'Normal weight';
              } elseif ($bmi >= 25 && $bmi < 30) {
                $bmi_category = 'Overweight';
              } else {
                $bmi_category = 'Obesity';
              }
            ?>
            <div class="info-card">
              <h3><i class="fas fa-calculator"></i> BMI</h3>
              <p><?php echo $bmi; ?> (<?php echo $bmi_category; ?>)</p>
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>